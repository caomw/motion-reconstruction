#include "motion.h"


motion::motion(void)
{
}


motion::~motion(void)
{
}

//motion::load(