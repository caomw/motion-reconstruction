﻿========================================================================
   Bachelor Project : Animation Database for Real-Time motion Reconstruction
========================================================================

Visual debugging tool
 Yellow current best OLNG path (neighbors highlighted in green)
 Orange minimization
 Red other best paths

 For help about controls, press h on runtime

    space - play
    a - turn random error on/off
    q/w - adjust error gain
    l - display bilinear interpolation
    o - switch neighbor sorting
    r - reset and reload input
    i - change input src
    p - continusou play
    c - display top paths
	y - console debug

model_view.cpp
	Functions related to blendshapes rendering

project.cpp
    Everything else, initialization, update loop, visual debugging tool

/////////////////////////////////////////////////////////////////////////////
